document.addEventListener('DOMContentLoaded', function() {

  // Header scroll
  var hdr = document.querySelector('.lx-hdr');
  if (hdr) window.addEventListener('scroll', function() { hdr.classList.toggle('scrolled', window.scrollY > 50); }, {passive:true});

  // Mobile drawer
  var toggle = document.getElementById('lx-toggle');
  var drawer = document.getElementById('lx-drawer');
  var overlay = document.getElementById('lx-overlay');
  if (toggle && drawer) {
    function openDrawer() { drawer.classList.add('open'); toggle.classList.add('open'); document.body.style.overflow = 'hidden'; }
    function closeDrawer() { drawer.classList.remove('open'); toggle.classList.remove('open'); document.body.style.overflow = ''; }
    toggle.addEventListener('click', function() { drawer.classList.contains('open') ? closeDrawer() : openDrawer(); });
    if (overlay) overlay.addEventListener('click', closeDrawer);
    document.addEventListener('keydown', function(e) { if (e.key === 'Escape') closeDrawer(); });
  }

  // FAQ accordion
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('.lx-faq__q');
    if (!btn) return;
    var ans = btn.nextElementSibling;
    var isOpen = btn.classList.contains('open');
    document.querySelectorAll('.lx-faq__q').forEach(function(q) { q.classList.remove('open'); });
    document.querySelectorAll('.lx-faq__a').forEach(function(a) { a.classList.remove('open'); });
    if (!isOpen) { btn.classList.add('open'); if (ans) ans.classList.add('open'); }
  });

  // Scroll fade-in
  var obs = new IntersectionObserver(function(entries) {
    entries.forEach(function(e) { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
  }, {threshold: 0.06});
  document.querySelectorAll('.lx-fade-in').forEach(function(el) { obs.observe(el); });

  // Qty buttons
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('[data-qty]');
    if (!btn) return;
    var input = btn.closest('.lx-qty').querySelector('.lx-qty__input, input[type="number"]');
    if (!input) return;
    var val = parseInt(input.value) || 1;
    input.value = btn.dataset.qty === '+' ? val + 1 : Math.max(1, val - 1);
  });

  // Collection filter
  document.addEventListener('click', function(e) {
    var btn = e.target.closest('[data-filter]');
    if (!btn) return;
    document.querySelectorAll('[data-filter]').forEach(function(b) {
      b.style.background = '#fff'; b.style.color = '#3b4758'; b.style.borderColor = '#eaecf0';
    });
    btn.style.background = '#00C2B8'; btn.style.color = '#fff'; btn.style.borderColor = '#00C2B8';
    var filter = btn.dataset.filter;
    document.querySelectorAll('.lx-pcard').forEach(function(card) {
      if (filter === 'all') { card.style.display = 'flex'; }
      else { var tags = (card.dataset.category || '').toLowerCase(); card.style.display = tags.indexOf(filter) > -1 ? 'flex' : 'none'; }
    });
  });

  // Quick view
  window.lxQuickView = function(handle) {
    var modal = document.getElementById('lx-qv-modal');
    if (!modal) return;
    modal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
    fetch('/products/' + handle + '.js').then(function(r) { return r.json(); }).then(function(p) {
      document.getElementById('lx-qv-cat').textContent = p.type || 'Supplement';
      document.getElementById('lx-qv-title').textContent = p.title;
      document.getElementById('lx-qv-price').textContent = '£' + (p.price/100).toFixed(2);
      document.getElementById('lx-qv-desc').textContent = p.body_html.replace(/<[^>]*>/g,'').substring(0,200) + '...';
      document.getElementById('lx-qv-link').href = '/products/' + handle;
      var img = document.getElementById('lx-qv-img');
      img.innerHTML = p.images.length ? '<img src="' + p.images[0].src + '" style="max-height:240px;max-width:100%;object-fit:contain">' : '';
      document.getElementById('lx-qv-form').innerHTML = '<form action="/cart/add" method="post"><input type="hidden" name="id" value="' + p.variants[0].id + '"><button type="submit" style="width:100%;padding:15px;background:#00C2B8;color:#fff;border:none;border-radius:100px;font-weight:700;font-size:15px;cursor:pointer;font-family:inherit">Add to Basket — £' + (p.price/100).toFixed(2) + '</button></form>';
    });
  };
  window.lxCloseQV = function() {
    var modal = document.getElementById('lx-qv-modal');
    if (modal) { modal.style.display = 'none'; document.body.style.overflow = ''; }
  };
  document.addEventListener('keydown', function(e) { if (e.key === 'Escape') lxCloseQV(); });

  // Delivery bar
  function lxUpdateDeliveryBar() {
    fetch('/cart.js').then(function(r) { return r.json(); }).then(function(cart) {
      var total = cart.total_price / 100;
      var threshold = 50;
      var remaining = Math.max(0, threshold - total);
      var pct = Math.min(100, (total / threshold) * 100);
      var bar = document.getElementById('lx-delivery-progress');
      var msg = document.getElementById('lx-delivery-msg');
      if (bar) bar.style.width = pct + '%';
      if (msg) msg.innerHTML = remaining <= 0 ? '<strong style="color:#009990">You have free UK delivery!</strong>' : 'Add <strong>£' + remaining.toFixed(2) + '</strong> more for free UK delivery';
    }).catch(function() {});
  }
  lxUpdateDeliveryBar();

});
